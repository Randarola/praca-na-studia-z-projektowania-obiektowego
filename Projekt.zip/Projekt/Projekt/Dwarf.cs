﻿using System;

namespace Projekt
{
    /// <summary>
    /// klasa Dwarf opisuje Krasnoludy
    /// </summary>
    public class Dwarf : AbstractRace
    {

        public Dwarf(Board board) : base(board) //konstruktor klasy
        {
            Name = "Dwarf";
        }

    }
}
