﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projekt
{
    /// <summary>
    /// Klasa Move odpowiada za ruch jednostek.
    /// <remarks> Jednorazowo każda jednostka jest w stanie zmienić swoje położenie o jedno pole na planszy. 
    /// Istoty mogą poruszać się w pionie, poziomie i po skosie. 
    /// Ich możliwości ruchu są ograniczane poprzez inne istoty oraz brzegi planszy
    /// </remarks>
    /// </summary>
    public class Move
    {
        /// <summary>
        /// Metoda, która sprawia, że istota zmienia swoje położenie dokładnie o jedno pole w losowym kierunku
        /// </summary>
        /// <param name="race"> istota u której zostaje wywołana metoda ruchu</param>
        /// <param name="board"> plansza, po której przemieszcza się określona istota</param>
        public void move(AbstractRace race, Board board)
        {
            Random rand = new Random(); //losowanie opcji ruchu
            int x = race.PlacedAt.X;
            int y = race.PlacedAt.Y;

            while (x == race.PlacedAt.X && y == race.PlacedAt.Y)    //potrzebny gdyby ruch się nie wykonał
            {
                switch (rand.Next(8))   //losuje jedną z opcji ruchu
                {
                    case 0:
                        {
                            if (board.TheGrid[race.PlacedAt.X + 1, race.PlacedAt.Y + 1].IsOccupied == false && x + 1 <= board.Size - 2 && y + 1 <= board.Size - 2)//sprawdza czy x i y są poprawne do wykonania ruchu
                            {
                                board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y].Reset();    //czyści stare pole
                                race.PlacedAt.X = x + 1;    //ustala nowe x
                                race.PlacedAt.Y = y + 1;    //ustala nowe y
                                board.PlaceRace(race);  //ustawia rasę na polu
                                race.TilesMoved++;
                            }
                            break;
                        }
                    case 1:
                        {
                            if (board.TheGrid[race.PlacedAt.X + 1, race.PlacedAt.Y - 1].IsOccupied == false && x + 1 <= board.Size - 2 && y - 1 >= 1 && y - 1 <= board.Size - 2)
                            {
                                board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y].Reset();
                                race.PlacedAt.X = x + 1;
                                race.PlacedAt.Y = y - 1;
                                board.PlaceRace(race);
                                race.TilesMoved++;
                            }
                            break;
                        }
                    case 2:
                        {
                            if (board.TheGrid[race.PlacedAt.X - 1, race.PlacedAt.Y + 1].IsOccupied == false && x - 1 >= 1 && y + 1 <= board.Size - 2)
                            {
                                board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y].Reset();
                                race.PlacedAt.X = x - 1;
                                race.PlacedAt.Y = y + 1;
                                board.PlaceRace(race);
                                race.TilesMoved++;
                            }
                            break;
                        }
                    case 3:
                        {
                            if (board.TheGrid[race.PlacedAt.X - 1, race.PlacedAt.Y - 1].IsOccupied == false && x - 1 >= 1 && y - 1 >= 1)
                            {
                                board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y].Reset();
                                race.PlacedAt.X = x - 1;
                                race.PlacedAt.Y = y - 1;
                                board.PlaceRace(race);
                                race.TilesMoved++;
                            }
                            break;
                        }
                    case 4:
                        {
                            if (board.TheGrid[race.PlacedAt.X + 1, race.PlacedAt.Y].IsOccupied == false && x + 1 <= board.Size - 2)
                            {
                                board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y].Reset();
                                race.PlacedAt.X = x + 1;
                                race.PlacedAt.Y = y;
                                board.PlaceRace(race);
                                race.TilesMoved++;
                            }
                            break;
                        }
                    case 5:
                        {
                            if (board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y + 1].IsOccupied == false && y + 1 <= board.Size - 2)
                            {
                                board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y].Reset();
                                race.PlacedAt.X = x;
                                race.PlacedAt.Y = y + 1;
                                board.PlaceRace(race);
                                race.TilesMoved++;
                            }
                            break;
                        }
                    case 6:
                        {
                            if (board.TheGrid[race.PlacedAt.X - 1, race.PlacedAt.Y].IsOccupied == false && x - 1 >= 1)
                            {
                                board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y].Reset();
                                race.PlacedAt.X = x - 1;
                                race.PlacedAt.Y = y;
                                board.PlaceRace(race);
                                race.TilesMoved++;
                            }
                            break;
                        }
                    case 7:
                        {
                            if (board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y - 1].IsOccupied == false && y - 1 >= 1)
                            {
                                board.TheGrid[race.PlacedAt.X, race.PlacedAt.Y].Reset();
                                race.PlacedAt.X = x;
                                race.PlacedAt.Y = y - 1;
                                board.PlaceRace(race);
                                race.TilesMoved++;
                            }
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }

        }
    }
}
