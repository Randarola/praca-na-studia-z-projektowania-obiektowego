﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projekt
{
    public enum Names
    {
        Elves,
        Humans,
        Dwarves,
        Wyverns,
        Ogres
    }
}
