﻿using System;
namespace Projekt
{
    /// <summary>
    /// klasa Ogre opisuje Ogry
    /// </summary>
    public class Ogre : AbstractRace
    {

        public Ogre(Board board) : base(board)  //konstruktor klasy
        {
            Name = "Ogre";
        }

    }
}
