﻿using System;

namespace Projekt
{
    /// <summary>
    /// Klasa CheckSquare służy sprawdzeniu informacji o wybranym polu na planszy
    /// <remarks> Do tych informacji należą:
    /// - czy pole jest zajęte
    /// - kto zajmuje pole  
    /// - jakie jest nastawienie danej jednostki do istoty znajdującej się na wybranym polu
    /// </remarks>
    /// </summary>
    public class CheckSquare
    {
        Fight fight = new Fight();

        public void checkSquare(Square area, AbstractRace creature, Board board, int a, int b)
        {
            int counter = -1;   //zmienna pomocnicza
            if (area.IsOccupied == true)
            {
                //sprawdzanie która rasa zajmuje pole
                switch (area.CurrentRace.Name)
                {
                    case "Elf":
                        {
                            counter = 0;
                            break;
                        }
                    case "Human":
                        {
                            counter = 1;
                            break;
                        }
                    case "Dwarf":
                        {
                            counter = 2;
                            break;
                        }
                    case "Wyvern":
                        {
                            counter = 3;
                            break;
                        }
                    case "Ogre":
                        {
                            counter = 4;
                            break;
                        }
                }

                //ustalanie reacji jednostki z spotkaną jednostką
                if (creature.Relations.relations[counter] == 0)
                {
                    if (creature.IsAlive == true)
                        fight.fight(creature, area.CurrentRace, board); //walka z wrogą jednostką
                }
                else if (creature.Relations.relations[counter] == 2)
                {
                    for (int i = -1; i < 2; i++)
                    {
                        for (int j = -1; j < 2; j++)
                        {
                            if (i != 0 && j != 0)
                            {
                                //sprawdzanie czy przyjaciej z kimś sąsaduje
                                checkFriendSquare(creature, board.TheGrid[creature.PlacedAt.X + b, creature.PlacedAt.Y + a].CurrentRace, board, board.TheGrid[creature.PlacedAt.X + j, creature.PlacedAt.Y + i]);
                            }
                        }
                    }
                }

            }
        }

        public void checkFriendSquare(AbstractRace creature, AbstractRace friend, Board board, Square area)
        {
            int counter = -1; //zmienna pomocnicza
            if (area.IsOccupied == true)
            {
                //sprawdzanie która rasa zajmuje pole
                switch (area.CurrentRace.Name)
                {
                    case "Elf":
                        {
                            counter = 0;
                            break;
                        }
                    case "Human":
                        {
                            counter = 1;
                            break;
                        }
                    case "Dwarf":
                        {
                            counter = 2;
                            break;
                        }
                    case "Wyvern":
                        {
                            counter = 3;
                            break;
                        }
                    case "Ogre":
                        {
                            counter = 4;
                            break;
                        }
                }

                if (friend.Relations.relations[counter] == 0)   //sprawdza czy sąsiad przyjaciela jest jego wrogiem
                {
                    if (creature.Relations.relations[counter] != 2)    //sprawdza czy sąsadujący wróg z przyjacielem nie jest przyjacielem jednostki
                    {
                        if (creature.IsAlive == true)
                        {
                            fight.fight(area.CurrentRace, creature, friend, board); //pomoc w walce z wrogiem przyjaciela
                        }

                    }

                }

            }
        }
    }
}
