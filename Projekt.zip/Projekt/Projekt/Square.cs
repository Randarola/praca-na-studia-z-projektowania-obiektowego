﻿namespace Projekt
{
    /// <summary>
    /// Klasa Square przechowuje informacje o wybranym polu
    /// <remarks> Każde pole opisane jest za pomocą zmiennych x, y. 
    /// Oznaczają one współrzędne danego pola na planszy
    /// <para>Pole może być zajęte przez członka jednej z pięciu ras lub pozostawać puste</para></remarks>
    /// </summary>
    public class Square
    {
        private int x; //Row
        private int y; //Column
        private bool isOccupied; //zwraca true gdy na nim jest jednostka rasy
        private AbstractRace currentRace; //rasa jaka znajduje się na polu

        public Square(int x, int y) //konstruktor square
        {
            this.x = x;
            this.y = y;
            isOccupied = false;
        }
        /// <summary>
        /// Metoda Reset() zwalnia dane pole, gdy istota przenosi się z niego na inne pole
        /// </summary>
        public void Reset() //ustawia false gdy jednostki już na nim nie ma
        {
            isOccupied = false;
            currentRace = null;
        }
        /// <summary>
        /// Metoda Set() umieszcza istotę na polu
        /// </summary>
        /// <param name="race"> istota, która zostaje przypisana do danego pola</param>
        public void Set(AbstractRace race)
        {
            isOccupied = true;
            currentRace = race;
        }

        public int X
        {
            get { return x; }
            set { x = value; }
        }

        public int Y
        {
            get { return y; }
            set { y = value; }
        }



        public bool IsOccupied
        {
            get { return isOccupied; }
            set { isOccupied = value; }
        }

        public AbstractRace CurrentRace
        {
            get { return currentRace; }
            set { currentRace = value; }
        }

    }
}
