﻿using System;
namespace Projekt
{
    /// <summary>
    /// klasa Elf opisuje Elfy
    /// </summary>
    public class Elf : AbstractRace
    {
        public Elf(Board board) : base(board)   //konstruktor klasy
        {
            Name = "Elf";
        }

    }
}
