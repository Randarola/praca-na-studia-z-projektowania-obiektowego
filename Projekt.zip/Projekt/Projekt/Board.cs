﻿using System;

namespace Projekt
{
    /// <summary>
    /// Klasa Board opisuje planszę, na której będą przebywać jednostki
    /// <remarks>Plansza składa się z kilkunastu pól, których ilość zależy  od tego, jaką ilość wprowadzi użytkownik przy uruchamianiu programu</remarks>
    /// </summary>
    public class Board
    {
        private int size;
        private Square[,] theGrid;

        //konstruktor
        public Board(int size)
        { 
            //wielkość planszy
            this.size = size;

            //2D tablica typu Square
            theGrid = new Square[size, size];


            //uzupełnianie 2D tablicy
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    theGrid[i, j] = new Square(j, i);
                }
            }
        }

        public int Size
        {
            get { return size; }
            set { size = value; }
        }

        public Square[,] TheGrid
        {
            get { return theGrid; }
            set { theGrid = value; }
        }
        /// <summary>
        /// Metoda PlaceRace() umieszcza istotę na odpowiednim polu należącym do planszy
        /// </summary>
        /// <param name="creature"> istota, która jest umieszczana na odpowiednim polu planszy</param>
        public void PlaceRace(AbstractRace creature)    //umieszcza członka rasy na odpowiednim polu planszy
        {
                TheGrid[creature.PlacedAt.X, creature.PlacedAt.Y].IsOccupied = true;
                TheGrid[creature.PlacedAt.X, creature.PlacedAt.Y].CurrentRace = creature;
        }
        /// <summary>
        /// Metoda PrintBoard() drukuje w konsoli planszę z widocznym podziałem na pola. 
        /// <remarks>Miejsca zajmowane przez istoty ras są oznaczane odpowiednią literą:
        /// - E: elfy
        /// - D: kransoludy
        /// - H: ludzie
        /// - O: ogry
        /// - W: wiwerny
        /// </remarks>
        /// </summary>
        public void PrintBoard()    //Metoda wyświetlania planszy
        {
            for (int i = 1; i < Size-1; i++)
            {
                for (int j = 1; j < Size-1; j++)
                {
                    Console.Write("+---");
                    if (j == Size-2)
                    {
                        Console.Write("+");
                    }
                }
                Console.WriteLine();
                for (int j = 1; j < Size-1; j++)
                {
                    Square s = TheGrid[j, i];
                    if (s.IsOccupied == true)
                    {
                        AbstractRace race = theGrid[j, i].CurrentRace;  //sprawdza jaka rasa jest na polu
                        Console.Write("| " + race.Name[0] + " ");
                        if (j == Size-2)
                        {
                            Console.Write("|");
                        }
                    }
                    else
                    {
                        Console.Write("|   ");
                        if (j == Size-2)
                        {
                            Console.Write("|");
                        }
                    }
                }

                Console.WriteLine();
            }
            for (int j = 1; j < Size-1; j++)
            {
                Console.Write("+---");
                if (j == Size-2)
                {
                    Console.Write("+");
                }
            }
            Console.WriteLine();


        }
    }
}
