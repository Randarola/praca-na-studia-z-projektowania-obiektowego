﻿using System;
namespace Projekt
{
    /// <summary>
    /// klasa Human opisuje Ludzi
    /// </summary>
    public class Human : AbstractRace
    {

        public Human(Board board) : base(board) //konstruktor klasy
        {
            Name = "Human";
        }

    }
}
