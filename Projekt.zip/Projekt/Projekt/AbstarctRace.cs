﻿using System;

namespace Projekt
{
    /// <summary>
    /// Klasa AbstractRace jest klasą abstrakcyjną, po której dziedziczą wszystkie rasy.
    /// <remarks>Te rasy to: 
    /// - elfy
    /// - krasnoludy 
    /// - ludzie
    /// - ogry
    /// - wiwerny</remarks>
    /// </summary>
    public abstract class AbstractRace
    {
        
        private string name;    //nazwa rasy 
        private Square placedAt;    // miejsce zajmowane na planszy przez rasę
        private Relations relations;
        private bool isAlive;
        private int fights=0;
        private int tilesMoved = 0;
        /// <summary>
        /// Konstruktor, który sprawia, że za każdym razem jak tworzy się istota zostaje ona umieszczona na losowym miejscu planszy
        /// </summary>
        /// <param name="board"> plansza, na której są umieszczane jednostki</param>
        public AbstractRace(Board board)    //konstruktor losujący miejsce
        {   
            isAlive = true;
            do
            {
                Random rand = new Random(); //generator liczb losowych
                placedAt = new Square(rand.Next(1, board.Size - 1), rand.Next(1, board.Size - 1));  //przypisywanie losowego x i y
            }
            while (board.TheGrid[placedAt.X, placedAt.Y].IsOccupied == true);

            board.PlaceRace(this);
        }

        public string Name  //geter name
        {
            get { return name; }
            set { name = value; }

        }
  
        public Square PlacedAt  //geter placedAt
        {
            get { return placedAt; }
            set { placedAt = value; }
        }

        public Relations Relations  //geter relations
        {
            get { return relations; }
            set { relations = value; }
        }
 
        public bool IsAlive
        {
            get { return isAlive; }
            set { isAlive = value; }
        }

        public int Fights
        {
            get { return fights; }
            set { fights = value; }
        }
        public int TilesMoved
        {
            get { return tilesMoved; }
            set { tilesMoved = value; }
        }
    }
}
