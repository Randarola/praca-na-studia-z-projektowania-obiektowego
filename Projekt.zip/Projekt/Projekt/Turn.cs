﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projekt
{   
    /// <summary>
    /// Klasa Turn zarządza jedną turą wybranej jednostki
    /// </summary>
    public class Turn
    {
        private CheckSquare check = new CheckSquare();
        private Move move = new Move();

        /// <summary>
        /// Metoda, wywołująca sprawdzenie wszystkich sąsiednich pól oraz ruch jednostki
        /// </summary>
        /// <param name="race"> istota, której tura się wykonuje</param>
        /// <param name="board"> plansza, po której porusza się istota  </param>
        public void turn(AbstractRace race, Board board)
        {
            for (int i = -1; i < 2; i++)
            {
                for (int j = -1; j < 2; j++)
                {
                    if (i != 0 || j != 0)
                    {
                        check.checkSquare(board.TheGrid[race.PlacedAt.X + j, race.PlacedAt.Y + i], race, board, i, j);
                    }
                }
            }
            if (race.IsAlive == true)
                move.move(race, board);
        }
    }
}
