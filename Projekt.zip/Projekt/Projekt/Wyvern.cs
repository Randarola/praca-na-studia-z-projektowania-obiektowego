﻿using System;
namespace Projekt
{
    /// <summary>
    /// klasa Wyvern opisuje Wiwerny
    /// </summary>
    public class Wyvern : AbstractRace
    {

        public Wyvern(Board board) : base(board)    //konstruktor klasy
        {
            Name = "Wyvern";
        }

    }
}

