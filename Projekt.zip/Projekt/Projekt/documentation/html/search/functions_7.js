var searchData=
[
  ['turn_46',['turn',['../class_projekt_1_1_turn.html#a3353693b05ea64434b73eae8c99af412',1,'Projekt::Turn']]]
];
