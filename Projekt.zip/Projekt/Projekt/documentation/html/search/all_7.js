var searchData=
[
  ['move_8',['move',['../class_projekt_1_1_move.html#a27c1f179a44bffb665bd69d69406d669',1,'Projekt::Move']]],
  ['move_9',['Move',['../class_projekt_1_1_move.html',1,'Projekt']]]
];
