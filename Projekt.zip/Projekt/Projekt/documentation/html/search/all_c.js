var searchData=
[
  ['turn_19',['Turn',['../class_projekt_1_1_turn.html',1,'Projekt']]],
  ['turn_20',['turn',['../class_projekt_1_1_turn.html#a3353693b05ea64434b73eae8c99af412',1,'Projekt::Turn']]]
];
