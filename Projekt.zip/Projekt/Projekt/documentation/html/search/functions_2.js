var searchData=
[
  ['move_39',['move',['../class_projekt_1_1_move.html#a27c1f179a44bffb665bd69d69406d669',1,'Projekt::Move']]]
];
