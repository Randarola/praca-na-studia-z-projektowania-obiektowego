var searchData=
[
  ['placedat_51',['PlacedAt',['../class_projekt_1_1_abstract_race.html#a18f37c94cf038004ce0286d1fd620d71',1,'Projekt::AbstractRace']]]
];
