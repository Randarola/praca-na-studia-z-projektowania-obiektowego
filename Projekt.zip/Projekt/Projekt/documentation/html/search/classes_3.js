var searchData=
[
  ['dwarf_25',['Dwarf',['../class_projekt_1_1_dwarf.html',1,'Projekt']]]
];
