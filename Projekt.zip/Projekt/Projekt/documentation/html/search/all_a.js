var searchData=
[
  ['relations_15',['Relations',['../class_projekt_1_1_relations.html',1,'Projekt.Relations'],['../class_projekt_1_1_relations.html#a8a75243ac0b44243a5586c10a91839b8',1,'Projekt.Relations.Relations()']]],
  ['reset_16',['Reset',['../class_projekt_1_1_square.html#a23a06ef577f5881d13bfd2c604aa44e8',1,'Projekt::Square']]]
];
