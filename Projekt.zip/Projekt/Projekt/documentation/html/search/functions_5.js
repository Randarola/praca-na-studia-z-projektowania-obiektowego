var searchData=
[
  ['set_44',['Set',['../class_projekt_1_1_square.html#a6eca1d6c9a6152b1fdb1c3a3b77a7b5a',1,'Projekt::Square']]]
];
