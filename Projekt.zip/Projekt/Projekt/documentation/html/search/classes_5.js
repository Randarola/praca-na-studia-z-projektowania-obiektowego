var searchData=
[
  ['fight_27',['Fight',['../class_projekt_1_1_fight.html',1,'Projekt']]]
];
