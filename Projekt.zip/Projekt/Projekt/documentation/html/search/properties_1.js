var searchData=
[
  ['name_50',['Name',['../class_projekt_1_1_abstract_race.html#a86fb1b8c0145b39d5a14727a277389ae',1,'Projekt::AbstractRace']]]
];
