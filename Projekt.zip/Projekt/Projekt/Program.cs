﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace Projekt
{
    /// <summary>
    /// Klasa Program zawiera metodę Main()
    /// <remarks>Stanowi podstawę całęgo programu. 
    /// Wywołuje pobranie od użytkownika odpowiednich wartości potrzebnych do przeprowadzenia symulacji.
    /// Odpowiada za utworzenie pliku CSV</remarks>
    /// </summary>
    class Program
    {
        const int MIN_SIZE = 7;
        const int MAX_SIZE = 50;
       
        static void Main(string[] args)
        {
            //tworzenie pliku csv
            var csvPath = Path.Combine(Environment.CurrentDirectory, "DataFromEras.csv");
            StringBuilder csvcontent = new StringBuilder();
            csvcontent.AppendLine("Name;Turn;Amount;Fights;Casualties;Tiles Moved");    //nagłowek w csv

            int size;
            Console.Write("Podaj rozmiar planszy (wprowadź liczbę między 7, a 50): ");  //minimalny rozmiar to 7
            do
            {
                size = Read(size = 0);
                if (size < MIN_SIZE || size > MAX_SIZE) Console.WriteLine("Wprowadź poprawną wartość");
            }
            while (size < MIN_SIZE || size > MAX_SIZE);

            Board board = new Board(size + 2);    //tworzy planszę o wielkości size (plansza jest kwadratem a size ilość squers jako bok czyli plansza będzie wielkości size x size)
            
            int max = size * size / 9;  //maksymalna liczba jednostek na planszy
            int[] raceNr = { 0, 0, 0, 0, 0 };   // przechowuje liczebnosc kazdej z ras w kolejnosc: elves, humans, dwarves, wyverns, ogres
            int nr = 0;
            int howmany;    //zmienna pomocnicza
            int eras = 0;   //ilość tur
            Console.Write("Podaj liczbę epok: ");
            do
            {
                eras = Read(eras);  //wczytywanie ilość tur
                if (eras <= 0)
                {
                    Console.WriteLine("Wprowadź poprawną wartość");
                }
            }
            while (eras <= 0);

            Turn turn = new Turn();   //tura

            Console.WriteLine("1: Przypisywanie ustalonej wartości rasom");
            Console.WriteLine("2: Przypisywanie domyślnych wartości");  //rozmiar planszy przez 3^2 razy ilość ras

            bool input = false; //zmiennna aby switch poprawnie działał 
            int choice = 0;
            do
            {
                switch (Read(choice))
                {
                    case 1:
                        {
                            while (max > raceNr.Sum() && nr != 5)
                            {
                                do
                                {
                                    Console.WriteLine($"Na planszy może być jeszcze maksylmanie {max - raceNr.Sum()} jednostek ras ");
                                    Console.Write($"Podaj ilość { (Names)nr}: ");
                                    howmany = Read(howmany = -1);
                                    if (howmany > max - raceNr.Sum() || howmany < 0)
                                        Console.WriteLine("Wprowadź poprawną wartość");
                                } while (howmany > max - raceNr.Sum() || howmany < 0);
                                raceNr[nr] = howmany;
                                nr++;
                            }
                            input = true;
                            break;
                        }

                    case 2:
                        {
                            Console.WriteLine($"Przypisano wszytkim rasom wartość: {max / 5}");
                            for (int i = 0; i < 5; i++)
                            {
                                raceNr[i] = max / 5;
                            }
                            input = true;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Wprowadź poprwaną wartość");
                            break;
                        }
                }
            } while (!input);





            Elf[] elves = new Elf[raceNr[0]];
            Human[] humans = new Human[raceNr[1]];
            Dwarf[] dwarves = new Dwarf[raceNr[2]];
            Wyvern[] wyvernes = new Wyvern[raceNr[3]];
            Ogre[] ogres = new Ogre[raceNr[4]];

            //przypisywanie relacji miedzy rasami
            StreamReader file = new StreamReader("../../../../Relations.txt");  //storzenie StreamReader pliku z relacjami
            string relations = file.ReadLine();  //wczytanie pierwszej linijki z pliku

            relations = file.ReadLine();    //wczytanie relacji elfów
            string[] values = relations.Split(","); //stworzenie tablicy z danymi kótre w pliku są rozdzielone ,
            Relations relationsElf = new Relations(Names.Elves, values);

            relations = file.ReadLine();    //wczytanie relacji ludzi
            values = relations.Split(",");
            Relations relationsHuman = new Relations(Names.Humans, values);

            relations = file.ReadLine();    //wczytanie relacji krasnoludów
            values = relations.Split(",");
            Relations relationsDwarves = new Relations(Names.Dwarves, values);

            relations = file.ReadLine();    //wczytanie relacji wywern
            values = relations.Split(",");
            Relations relationsWyverns = new Relations(Names.Wyverns, values);

            relations = file.ReadLine();    //wczytanie relacji smoków
            values = relations.Split(",");
            Relations relationsOgres = new Relations(Names.Ogres, values);


            //uzupełnianie tablic z jednostkami ras
            for (int i = 0; i < raceNr[0]; i++)
            {
                elves[i] = new Elf(board)
                {
                    Relations = relationsElf
                };
            }

            for (int i = 0; i < raceNr[1]; i++)
            {
                humans[i] = new Human(board)
                {
                    Relations = relationsHuman
                };
            }

            for (int i = 0; i < raceNr[2]; i++)
            {
                dwarves[i] = new Dwarf(board)
                {
                    Relations = relationsDwarves
                };
            }

            for (int i = 0; i < raceNr[3]; i++)
            {
                wyvernes[i] = new Wyvern(board)
                {
                    Relations = relationsWyverns
                };
            }

            for (int i = 0; i < raceNr[4]; i++)
            {
                ogres[i] = new Ogre(board)
                {
                    Relations = relationsOgres
                };
            }

            Console.Clear();


            for (int i = 0; i < eras; i++)
            {
                //tworzenie zmienych do pliku csv
                int fightsElves = 0;
                int casualtiesElves = 0;
                int tilesMovedElves = 0;

                int fightsHumans = 0;
                int casualtiesHumans = 0;
                int tilesMovedHumans = 0;

                int fightsDwarves = 0;
                int casualtiesDwarves = 0;
                int tilesMovedDwarves = 0;

                int fightsWyvernes = 0;
                int casualtiesWyvernes = 0;
                int tilesMovedWyvernes = 0;

                int fightsOgres = 0;
                int casualtiesOgres = 0;
                int tilesMovedOgres = 0;

                for (int j = 0; j < raceNr[0]; j++)
                {
                    if (elves[j].IsAlive == true)
                    {
                        Console.Clear();     //czyści konsolę
                        board.PrintBoard();  //wyświetla planszę w konsoli
                        turn.turn(elves[j], board);
                        Thread.Sleep(750);
                        fightsElves += elves[j].Fights; //sumowanie walk elfów
                        tilesMovedElves += elves[j].TilesMoved; //sumowanie pól przebytych przez elfy
                        if (elves[j].IsAlive == false) //gdyby jednostka poległa w pierwszej turze
                        {
                            casualtiesElves++;
                        }
                    }
                    else
                    {
                        fightsElves += elves[j].Fights;
                        tilesMovedElves += elves[j].TilesMoved;
                        casualtiesElves++;
                    }
                }
                csvcontent.AppendLine($"Elves;{i + 1};{raceNr[0] - casualtiesElves};{fightsElves};{casualtiesElves};{tilesMovedElves}");


                for (int j = 0; j < raceNr[1]; j++)
                {
                    if (humans[j].IsAlive == true)
                    {
                        Console.Clear();
                        board.PrintBoard();
                        turn.turn(humans[j], board);
                        Thread.Sleep(750);
                        fightsHumans += humans[j].Fights;
                        tilesMovedHumans += humans[j].TilesMoved;
                        if (humans[j].IsAlive == false)
                        {
                            casualtiesHumans++;
                        }
                    }
                    else
                    {
                        fightsHumans += humans[j].Fights;
                        tilesMovedHumans += humans[j].TilesMoved;
                        casualtiesHumans++;
                    }
                }
                csvcontent.AppendLine($"Humans;{i + 1};{raceNr[1] - casualtiesHumans};{fightsHumans};{casualtiesHumans};{tilesMovedHumans}");


                for (int j = 0; j < raceNr[2]; j++)
                {
                    if (dwarves[j].IsAlive == true)
                    {

                        Console.Clear();
                        board.PrintBoard();
                        turn.turn(dwarves[j], board);
                        Thread.Sleep(750);
                        fightsDwarves += dwarves[j].Fights;
                        tilesMovedDwarves += dwarves[j].TilesMoved;
                        if (dwarves[j].IsAlive == false)
                        {
                            casualtiesDwarves++;
                        }
                    }
                    else
                    {
                        fightsDwarves += dwarves[j].Fights;
                        tilesMovedDwarves += dwarves[j].TilesMoved;
                        casualtiesDwarves++;
                    }
                }
                csvcontent.AppendLine($"Dwarves;{i + 1};{raceNr[2] - casualtiesDwarves};{fightsDwarves};{casualtiesDwarves};{tilesMovedDwarves}");


                for (int j = 0; j < raceNr[3]; j++)
                {
                    if (wyvernes[j].IsAlive == true)
                    {

                        Console.Clear();
                        board.PrintBoard();
                        turn.turn(wyvernes[j], board);
                        Thread.Sleep(750);
                        fightsWyvernes += wyvernes[j].Fights;
                        tilesMovedWyvernes += wyvernes[j].TilesMoved;
                        if (wyvernes[j].IsAlive == false)
                        {
                            casualtiesWyvernes++;
                        }
                    }
                    else
                    {
                        fightsWyvernes += wyvernes[j].Fights;
                        tilesMovedWyvernes += wyvernes[j].TilesMoved;
                        casualtiesWyvernes++;

                    }
                }
                csvcontent.AppendLine($"Wyvernes;{i + 1};{raceNr[3] - casualtiesWyvernes};{fightsWyvernes};{casualtiesWyvernes};{tilesMovedWyvernes}");


                for (int j = 0; j < raceNr[4]; j++)
                {
                    if (ogres[j].IsAlive == true)
                    {
                        Console.Clear();
                        board.PrintBoard();
                        turn.turn(ogres[j], board);
                        Thread.Sleep(750);
                        fightsOgres += ogres[j].Fights;
                        tilesMovedOgres += ogres[j].TilesMoved;
                        if (ogres[j].IsAlive == false)
                        {
                            casualtiesOgres++;
                        }
                    }
                    else
                    {
                        fightsOgres += ogres[j].Fights;
                        tilesMovedOgres += ogres[j].TilesMoved;
                        casualtiesOgres++;
                    }
                }
                csvcontent.AppendLine($"Ogres;{i + 1};{raceNr[4] - casualtiesOgres};{fightsOgres};{casualtiesOgres};{tilesMovedOgres}");
            }

            Console.Clear();
            board.PrintBoard();
            File.AppendAllText(csvPath, csvcontent.ToString()); //wpisywanie danych do pliku csv
            Console.ReadLine();

            int Read(int value)    //funkcja wczytywania
            {
                try
                {
                    value = Convert.ToInt32(Console.ReadLine());
                    return value;
                }
                catch (FormatException)
                {
                    return value;
                }
            }

        }



    }
}
