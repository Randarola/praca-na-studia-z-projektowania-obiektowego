﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projekt
{
    /// <summary>
    /// Klasa Fight odpowiada za przeprowadzenie walki między sąsiednimi jednostkami. 
    /// <remarks> Gdy jednostka ma wrogie nastawienie do istoty na sąsiednim polu, dochodzi do walki między nimi. Przegrany umiera i znika z planszy.
    /// Wygrany przeprowadza do końca swoją turę</remarks>
    /// </summary>

    public class Fight
    {
        /// <summary>
        /// Funkcja ta odpowiada za klasyczną walkę, w  której biorą udział dwie istoty
        /// </summary>
        /// <param name="attacker"> agresor, istota, która ma wrogie nastawienie do istoty znajdującej się na sąsiednim polu</param>
        /// <param name="defender"> obrońca, istota zaatakowana przez agresora</param>
        /// <param name="board"> plansza na której znajdują się istoty</param>
        public void fight(AbstractRace attacker, AbstractRace defender, Board board)    //pojedyncza walka
        {
            attacker.Fights++;
            defender.Fights++;
            Random result = new Random();
            switch (result.Next(2))
            {
                case 0:
                    {
                        board.TheGrid[attacker.PlacedAt.X, attacker.PlacedAt.Y].Reset();    //atacker przegrał i umiera
                        attacker.IsAlive = false;
                        break;
                    }
                case 1:
                    {
                        board.TheGrid[defender.PlacedAt.X, defender.PlacedAt.Y].Reset();    //defender przegrał i umiera
                        defender.IsAlive = false;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }



        }
        /// <summary>
        /// Funkcja ta jest odpowiedzialna za walkę w sytuacji, gdy jedna z jednostek otrzymuje pomoc "z zewnątrz". 
        /// W przypadku, gdy istota walcząca razem z helperem przegrywa, obie istoty znikają z planszy.
        /// </summary>
        /// <param name="attacker"> agresor, istota, która ma wrogie nastawienie do istoty znajdującej się na sąsiednim polu</param>
        /// <param name="defender"> obrońca, istota zaatakowana przez agresora</param>
        /// <param name="helper"> pomocnik, wspomaga w walce istotę, do której jest przyjaźnie nastawiony</param>
        /// <param name="board"> plansza na której znajdują się istoty</param>
        public void fight(AbstractRace attacker, AbstractRace defender, AbstractRace helper, Board board)   //walka z helperem 
        {
            attacker.Fights++;
            defender.Fights++;
            helper.Fights++;
            Random result = new Random();
            switch (result.Next(3))
            {
                case 0:
                    {
                        board.TheGrid[attacker.PlacedAt.X, attacker.PlacedAt.Y].Reset();    //atacker przegrał i umiera
                        attacker.IsAlive = false;
                        break;
                    }
                case 1:
                    {
                        board.TheGrid[defender.PlacedAt.X, defender.PlacedAt.Y].Reset();    //defender i helper przegrali i umierają
                        defender.IsAlive = false;
                        board.TheGrid[helper.PlacedAt.X, helper.PlacedAt.Y].Reset();
                        helper.IsAlive = false;
                        break;
                    }
                case 2:
                    {
                        board.TheGrid[attacker.PlacedAt.X, attacker.PlacedAt.Y].Reset();    //atacker przegrał i umiera
                        attacker.IsAlive = false;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
    }
}
