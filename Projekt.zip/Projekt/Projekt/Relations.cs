﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projekt
{
    /// <summary>
    /// Klasa Relations przechowuje informacje  o stosunkach między istotami ras.
    /// <remarks> Każda istota wobec drugiej istoty może mieć jedno z trzech nastawień:
    /// <para>- wrogie</para>
    /// <para>- neutralne</para>
    /// <para>- przyjazne</para>
    /// Od nastawienia zależy, co się wykona, gdy obok siebie znajdą się jakieś istoty
    /// </remarks>
    /// </summary>
    public class Relations
    {
        /*
         nastawienie do rasy w kolejnosc: elves, humans, dwarves, wyverns, ogres
             0 - wrogi do danej rasy
             1 - neutralny do danej rasy
             2 - przyjacielskie nastawienie do rasy 
        */

        public int[] relations = { 1, 1, 1, 1, 1 };
        /// <summary>
        /// Metoda pobierająca dane o relacjach z pliku tekstowego
        /// </summary>
        /// <param name="race"> istota, do której przypisywane jest nastawienie </param>
        /// <param name="file"> plik, w którym są zapisane relacje między poszczególnymi rasami</param>
        public Relations(Enum race, string[] file)
        {
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    relations[i] = Convert.ToInt32(file[i + 1]);
                }
                catch (FormatException)
                {
                    relations[i] = 1;
                }

            }
        }

    }
}
